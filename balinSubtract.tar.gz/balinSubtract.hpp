#ifndef BALIN_SUBTRACT_H
#define BALIN_SUBTRACT_H

#include <iostream>

/** 
 *  @Functionality: subracts b from a. Or more clearly "a - b"
 *  @Params: integer a, and integer b
 */
int subtract(int a, int b);


#endif
