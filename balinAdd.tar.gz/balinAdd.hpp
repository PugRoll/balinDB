#ifndef BALIN_ADD_H
#define BALIN_ADD_H

#include <iostream>

int add(int a, int b);


#endif 
